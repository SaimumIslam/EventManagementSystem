<!DOCTYPE html>
<html>
<head>
	<title>Event Management</title>
	<link rel="stylesheet" type="text/css" href="../css/header.css">
</head>
<body>

<ul>
	<li><a href="../index.php">Home</a></li>
	<li><a href="signin.php">Sign In</a></li>
	<li><a href="signup.php">Sign Up</a></li>
	<li class="about"><a href="aboutus.php">About Us</a></li>
</ul>

<div class="mainbody">