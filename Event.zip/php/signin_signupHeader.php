<!DOCTYPE html>
<html>
<head>
	<title>signin_signup_header</title>
	<link rel="stylesheet" type="text/css" href="../css/signin_signupHeader.css">
</head>
<body>

<ul>
	<li><a href="../index.php">Home</a></li>
	<li><a href="signin.php">Sign In</a></li>
	<li><a href="signup.php">Sign Up</a></li>
	<li class="about"><a href="aboutus.php">About Us</a></li>
</ul>

<h1>Welcome to Event Management Site</h1>

</body>
</html>