</div>

<footer><?php echo "&copy" .date('Y')."All right reserved" ?></footer>
</body>
</html>
