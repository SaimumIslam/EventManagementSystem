<!DOCTYPE html>
<html>
<head>
	<title>Event Management</title>
	<link rel="stylesheet" type="text/css" href="../css/mainpage.css">
</head>
<body>

<ul>
	<li><a href="../index.php">Home</a></li>
	<li><a href="messenger.php">Messege</a></li>
	<li><a href="createevent.php">Create Event</a></li>
	<li><a href="allevent.php">All Event</a></li>
	<li><a href="../controller/signoutAction.php">Sign Out</a></li>

	<li class="about"><a href="aboutus.php">About Us</a></li>
</ul>

<div class="mainbody">